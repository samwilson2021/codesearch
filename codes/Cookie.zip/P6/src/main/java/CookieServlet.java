import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/cookie")
public class CookieServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Create cookies
        Cookie userCookie = new Cookie("username", username);
        Cookie passCookie = new Cookie("password", password);

        // Add cookies to response
        response.addCookie(userCookie);
        response.addCookie(passCookie);

        // Create session
        HttpSession session = request.getSession();

        // Output response
        out.println("<html><body>");
        out.println("<h2>Cookies and Session Info</h2>");
        out.println("Username: " + username + "<br>");
        out.println("Password: " + password + "<br>");
        out.println("Session ID: " + session.getId() + "<br>");
        out.println("</body></html>");
    }
}
