import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String jdbcURL = "jdbc:mysql://localhost:3306/p3"; // change this
        String dbUser = "root"; // change this
        String dbPassword = "root"; // change this

        String inputUsername = request.getParameter("username");
        String inputPassword = request.getParameter("password");

        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, inputUsername);
            statement.setString(2, inputPassword);

            ResultSet result = statement.executeQuery();

            if (result.next()) {
                out.println("<h2>Login Successful!</h2>");
            } else {
                out.println("<h2>Invalid username or password.</h2>");
            }

            result.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace(out);
        }
    }
}
