package myapp.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import myapp.form.LoginForm;
import org.apache.struts.action.*;

public class LoginAction extends Action {
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        LoginForm loginForm = (LoginForm) form;
        String username = loginForm.getUsername();
        String password = loginForm.getPassword();

        // Dummy validation (you can replace this with database logic)
        if ("admin".equals(username) && "admin123".equals(password)) {
        	HttpSession session = request.getSession();
            session.setAttribute("user", username);
            return mapping.findForward("success");
        } else {
            request.setAttribute("errorMessage", "Incorrect username or password.");
            return mapping.findForward("failure");
        }
    }
}
