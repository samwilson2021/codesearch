import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/display")
public class DisplayServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get username from request
        String username = request.getParameter("username");

        // Create session and store username
        HttpSession session = request.getSession();
        session.setAttribute("username", username);

        // Track session with cookie
        Cookie sessionCookie = new Cookie("JSESSIONID", session.getId());
        sessionCookie.setMaxAge(30 * 60); // 30 minutes
        response.addCookie(sessionCookie);

        // Set content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get current date and time
        Date now = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("EEEE, dd MMM yyyy HH:mm:ss");

        // Retrieve from session
        String storedName = (String) session.getAttribute("username");

        // Display HTML
        out.println("<html><head><title>Session Output</title></head><body>");
        out.println("<h2>Hello, " + storedName + "! Welcome back.</h2>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p>Date and Time: " + formatter.format(now) + "</p>");
        out.println("</body></html>");
    }
}
