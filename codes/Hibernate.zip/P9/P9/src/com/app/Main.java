package com.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        // Create SessionFactory
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml") // Load hibernate.cfg.xml configuration
                .addAnnotatedClass(Department.class) // Add the Department class
                .addAnnotatedClass(Employee.class)  // Add the Employee class
                .buildSessionFactory();

        // Create session
        Session session = factory.getCurrentSession();

        try {
            // Start a transaction
            session.beginTransaction();

            // Create a new Department and Employee objects
            Department department = new Department("HR");

            Employee employee1 = new Employee("John");
            Employee employee2 = new Employee("Jane");

            // Set the department for the employees
            employee1.setDepartment(department);
            employee2.setDepartment(department);

            // Save the department and employees
            session.save(department);
            session.save(employee1);
            session.save(employee2);

            // Commit transaction
            session.getTransaction().commit();

            System.out.println("Employees and Department saved successfully!");
        } finally {
            factory.close();
        }
    }
}
